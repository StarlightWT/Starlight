# Starlight
This project is for a personal website and a final project for school.

It's just css, html and a bit of javascript used as a central hub. In the future there will be a blog which will include motorcycle and software development content.
