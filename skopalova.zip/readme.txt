brave (chromium)
https://starlightwt.github.io/Starlight